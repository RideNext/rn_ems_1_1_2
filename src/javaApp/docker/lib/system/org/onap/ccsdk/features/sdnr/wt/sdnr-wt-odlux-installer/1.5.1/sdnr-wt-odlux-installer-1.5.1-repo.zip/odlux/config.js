require.config({
  "paths": {
    "app": "app.js?v=1884afb4dfb921cccabb"
  },
  "baseUrl": ""
, waitSeconds: 30})