# Event Log

The 'EventLog'  application displays application logs and messages automatically created by the different active applications.
SDN-R offers a common log service so that PNFs or other ONAP components can log their data and users can analyze and export the data in a common way.


